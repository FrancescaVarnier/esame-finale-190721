export class Attrazione{
    id:number;
    attractionName:string;
    city:string;
    address:string;
    interestType:string;
    distanceFromHome:string;
    imageAttraction: ImageBitmap;
    numberPeoplePresent: string[];
    numberPeopleEntry: string[];
    numberPeopleExit: string[];
    stay: string[];
    dogsAllowed: ImageBitmap;
}