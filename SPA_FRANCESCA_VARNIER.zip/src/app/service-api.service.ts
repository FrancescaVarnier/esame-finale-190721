import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Attrazione } from "./models/attrazione";
import { openingTime } from "./models/orari";
import { Biglietto } from "./models/biglietti";

@Injectable({
  providedIn: "root",
})
export class ServiceApiService {
  constructor(private http: HttpClient) {}

  //ritorna la lista di tutte le attrazioni
  getAttrazioni() {
    return this.http.get<Attrazione[]>("http://localhost:3000/attrazione");
  }

  //ritorna dettaglio attrazione
  getAttrazioneDetail(id: number) {
    return this.http.get<Attrazione>("http://localhost:3000/attrazione/" + id);
  }

  //ritorna la lista degli orari
  getListaOrari() {
    return this.http.get<openingTime[]>("http://localhost:3000/openingTime");
  }

  //ritorna lista dei biglietti
  getBiglietti() {
    return this.http.get<Biglietto[]>("http://localhost:3000/biglietti");
  }
}
