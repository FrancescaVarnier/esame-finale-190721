import { Component, OnInit } from '@angular/core';
import { Attrazione } from '../models/attrazione';
import { ServiceApiService } from '../service-api.service';

@Component({
  selector: 'app-lista-attrazioni',
  templateUrl: './lista-attrazioni.component.html',
  styleUrls: ['./lista-attrazioni.component.css']
})
export class ListaAttrazioniComponent implements OnInit {

  constructor(private service: ServiceApiService) { }

  public lista_attrazioni: Attrazione[];

  public dettaglio;

  ngOnInit(): void {
    this.service.getAttrazioni().subscribe(data=> {
      this.lista_attrazioni = data;
    });
  }

}
