import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaAttrazioniComponent } from './lista-attrazioni.component';

describe('ListaAttrazioniComponent', () => {
  let component: ListaAttrazioniComponent;
  let fixture: ComponentFixture<ListaAttrazioniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaAttrazioniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaAttrazioniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
