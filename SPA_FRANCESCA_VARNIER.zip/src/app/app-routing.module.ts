import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DettaglioAttrazioniComponent } from './dettaglio-attrazioni/dettaglio-attrazioni.component';
import { ListaAttrazioniComponent } from './lista-attrazioni/lista-attrazioni.component';


const routes: Routes = [
  {path: '', component: ListaAttrazioniComponent },
  {path: 'dettaglio-attrazione/:id', component: DettaglioAttrazioniComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
