import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DettaglioAttrazioniComponent } from './dettaglio-attrazioni.component';

describe('DettaglioAttrazioniComponent', () => {
  let component: DettaglioAttrazioniComponent;
  let fixture: ComponentFixture<DettaglioAttrazioniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DettaglioAttrazioniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DettaglioAttrazioniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
