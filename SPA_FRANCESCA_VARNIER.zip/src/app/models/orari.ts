export class openingTime{
    id: number;
    giornoAperture : string[];
    orarioAperture : string[];
    periodoDal: string;
    periodoAl: string;
}

