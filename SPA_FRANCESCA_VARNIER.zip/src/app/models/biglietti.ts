export class Biglietto{
    idBiglietto: number;
    tipologia: string;
    prezzo: number;
    descrizione: string;
}