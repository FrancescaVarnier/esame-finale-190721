import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Attrazione } from '../models/attrazione';
import { Biglietto } from '../models/biglietti';
import { openingTime } from '../models/orari';
import { ServiceApiService } from '../service-api.service';


@Component({
  selector: 'app-dettaglio-attrazioni',
  templateUrl: './dettaglio-attrazioni.component.html',
  styleUrls: ['./dettaglio-attrazioni.component.css']
})
export class DettaglioAttrazioniComponent implements OnInit {

  id: number = 0;
  attrazione: Attrazione;
  orari: openingTime[];
  biglietto: Biglietto[];


  constructor(private service: ServiceApiService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(param => {
      let x = param.get('id');
      this.id = parseInt(x);

      this.service.getAttrazioneDetail(this.id).subscribe(data => {
        this.attrazione = data;
      }); 

      this.service.getListaOrari().subscribe(data => {
        this.orari = data;
      });

      this.service.getBiglietti().subscribe(data => {
        this.biglietto = data;
      })
    })
  }
}